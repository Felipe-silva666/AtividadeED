#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <conio.h>
#include <fstream>
#include <locale.h>
#include <windows.h>

//intern files
#include "Intern/exitQuestion.cpp"

//declarate constants
#define maximo 100 // Limite de Alunos

// Defini��o e constru��o da fila
struct TipoFila{
    int inicio, final, quantidade;
    struct aluno dado[maximo];
}; 

typedef struct TipoFila Fila;

//declarate functios
int Menu();
int ShowMenu(bool menuSelection[5]);

Fila* cria_Fila();

// Fun��o para retornar o tamanho da fila 
int tamanho_Fila(Fila* fi);

// Fun��o remover da fila
int remove_Fila(Fila* fi);

// Fun��o para inserir uma struct na fila
int insere_Fila(Fila* fi, struct aluno);

// Fun��o para mostrar toda a fila, os prints podem ser alterados a medida da necessidade do programa
void imprime_Fila(Fila* fi);

// Fun��o para fila vazia e cheia
int Fila_vazia(Fila* fi);
int Fila_cheia(Fila* fi);

// Consultar conte�do da fila
int consulta_Fila(Fila* fi, struct aluno *al);

//declarate variables
int i, ex = 0;
bool menuSelection[4], closeMenu, selectedExercise;
char pressedKey, sArrow[4];

int main (){
	setlocale(LC_ALL, "Portuguese");

	Fila* fi = cria_Fila();
	
	//I just will not put "system color" because in some computers it does not work properly :(
	
	//Clean old selected exercise
	for(i = 1; i <= sizeof(menuSelection); i++){
		menuSelection[i] = 0;
	}
	menuSelection[0] = 1;
	i = 0;
	
	Menu();
	
	if(selectedExercise){
		for(int i = 0; i < sizeof(menuSelection); i++){
			if(menuSelection[i] == 1){
				switch (i){
					case 0: system("cls"); insere_Fila(fi, dado); break;
					case 1: system("cls"); imprime_Fila(); break;
					case 2: system("cls"); remove_Fila(); break;
					case 3: system("cls"); libera_Fila(); break;
//					case 0:
//						system("cls");
//						// fun��o insere_Fila
//					    
//						if(fi == NULL)
//							main();
//						
//						if(Fila_cheia(fi))
//							main();
//						
//						fi -> dado[fi -> final] = aluno;
//						fi -> final = (fi-> final + 1) %maximo;
//						fi -> quantidade++;
//						
//						break;
//					case 1: system("cls"); imprime_Fila(); break;
//					case 2: system("cls"); remove_Fila(); break;
//					case 3: system("cls"); libera_Fila(); break;
					case 4: system("cls"); closeMenu = true; break;
					default: 
						printf("\n\nEsta fun��o n�o existe. \033[91m:(\033[0m\n\n");
			    		system("pause");
			    		system("cls");
			    		main();
				}
			}
		}
	}
	
	ExitQuestion();
	//Closing the program
	system("cls");
	
	printf("\"Si puedes convencerlos, conf�ndelos\".\nPor Harry Truman");
	
	printf("\n\nPrograma desenvolvido por\n - \033[91mGuilherme Mandeli Fernandes Camacho \n\033[0m - \033[91mFelipe da Silva Joaquin\033[0m\n");
	getch();
	exit(0);
}

int Menu(){
	closeMenu = false;
	selectedExercise = false;
	
	while(!closeMenu){
		ShowMenu(menuSelection);
		
		//Read pressed key
		pressedKey = _getch();
		
		//Select option in menu
		if(pressedKey == 0x4D or pressedKey == 0x50){ //Right arrow | Up arrow
			menuSelection[i] = 0;
			i++;
			menuSelection[i] = 1;
		} else if(pressedKey == 0x4B or pressedKey == 0x48){ //Left arrow | Down arrow
			menuSelection[i] = 0;
			i--;
			menuSelection[i] = 1;
		}
	
		//Infinite scroll menu
		if(menuSelection[-1] == 1){
			menuSelection[i] = 0;
			i = sizeof(menuSelection)-1;
			menuSelection[sizeof(menuSelection)-1] = 1;
		} else if(menuSelection[sizeof(menuSelection)] == 1){
			menuSelection[i] = 0;
			i = 0;
			menuSelection[0] = 1;
		}
		
		//Exit of the cycle to enter the selected exercise
		if(pressedKey == 0X0D){ //Enter Key
			selectedExercise = true;
			closeMenu = true;
		}
		
		//Exit of the cycle after the user want to close the program
		if(pressedKey == 0x63 or pressedKey == 0x43){ //C Key
			closeMenu = true;
			
			//Open the question to exit
			return EXIT_SUCCESS;
		}
	}
	
	return 0;
}


int ShowMenu(bool menuSelection[5]){
	//menuItems
	char options[4][20] = {"Adicionar aluno", "Exibir dados", "Retirar dado", "Limpar todos os dados", "Sair"};
	
	//show selected option
	for(int i = 0; i <= sizeof(menuSelection)+1; i++){
		if(menuSelection[i] == 1) sArrow[i] = '>';
		else sArrow[i] = ' ';
	}
	
	system("cls");
	printf("APS 3� Semestre \033[44m \033[97mEstrutura de Dados \033[0m\n\n");
	
	printf("- Use as setas do teclado para selecionar a op��o.\n");
	printf("- Bot�o 'Enter' para abrir a sele��o.\n\n");
	
	//show menu
	std::ifstream f("ASCIIart/Owl.txt");
	if(f.is_open()) cout << f.rdbuf(); //Show Owl
	printf("\n\033[44m                       \" \"                     \n");
	printf("\033[97m");
	printf("\033[0m");
	for(int i = 0; i <= 3; i++){
		cout << "\n " << i+1 << " | " << sArrow[i] << " " << options[i];
	}
	printf("   \n\n\033[44m                                               \033[0m");
	
	printf("\n\n- Bot�o 'C' para fechar o programa.");
	
	return 0;
}


/*  <  Estrutura de Dados dos Alunos  >  */

int consulta_Fila(Fila* fi, struct aluno *al){
    if(fi == NULL || Fila_vazia(fi))
        return 0;
    *al = fi -> dado[fi -> inicio];
    return 1;
}

Fila* cria_Fila(){  
	Fila *fi;
    fi = (Fila*)malloc(sizeof(struct TipoFila));
	if(fi != NULL){
        fi -> inicio = 0;
        fi -> final = 0;
        fi -> quantidade = 0;
    }
    return fi;
}

int Fila_cheia(Fila* fi){
    if(fi == NULL)
        return -1;
    if (fi -> quantidade == maximo)
        return 1;
    else
        return 0;
}

int Fila_vazia(Fila* fi){
    if(fi == NULL)
        return -1;
    if (fi -> quantidade == 0)
        return 1;
    else
        return 0;
}

void imprime_Fila(Fila* fi){
    if(fi == NULL)
        return;
    int n, i = fi -> inicio;
    for(n = 0; n < fi -> quantidade; n++){
        printf("Matricula: %d\n", fi -> dado[i].matricula);
        printf("Nome: %s\n", fi -> dado[i].nome);
        printf("Avalia��es: %.2f %.2f %.2f\n", fi -> dado[i].avaliacao1, fi -> dado[i].avaliacao2, fi -> dado[i].avaliacao3);
        i = (i + 1) %maximo;
    }
}

int insere_Fila(Fila* fi, struct aluno){
    if(fi == NULL)
        return 0;
    if(Fila_cheia(fi))
        return 0;
    fi -> dado[fi -> final] = aluno;
    fi -> final = (fi-> final + 1) %maximo;
    fi -> quantidade++;
    return 1;
}

// Fun��o para liberar a fila, utilizando "free"
void libera_Fila(Fila* fi){
    free(fi);
}

int remove_Fila(Fila* fi){
    if(fi == NULL || Fila_vazia(fi))
        return 0;
    fi -> inicio = (fi -> inicio + 1) %maximo;
    fi -> quantidade--;
    return 1;
}

int tamanho_Fila(Fila* fi){
    if(fi == NULL)
        return - 1;
    return fi -> quantidade;
}

