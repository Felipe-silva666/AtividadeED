// Defini��o e constru��o da fila
struct TipoFila{
    int inicio, final, quantidade;
    struct aluno dado[100];
}; 
typedef struct TipoFila Fila;
