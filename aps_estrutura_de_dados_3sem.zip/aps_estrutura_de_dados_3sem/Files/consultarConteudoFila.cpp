
// Consultar conte�do da fila
int consulta_Fila(Fila* fi, struct aluno *al);

int consulta_Fila(Fila* fi, struct aluno *al){
    if(fi == NULL || Fila_vazia(fi))
        return 0;
    *al = fi -> dado[fi -> inicio];
    return 1;
}
