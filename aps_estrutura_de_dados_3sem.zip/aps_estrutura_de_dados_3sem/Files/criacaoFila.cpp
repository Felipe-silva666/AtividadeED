
// Fun��o para a cria��o da fila
Fila* cria_Fila();

Fila* cria_Fila(){
    
	Fila *fi;
    fi = (Fila*)malloc(sizeof(struct TipoFila));
	if(fi != NULL){
        fi -> inicio = 0;
        fi -> final = 0;
        fi -> quantidade = 0;
    }
    return fi;
}
