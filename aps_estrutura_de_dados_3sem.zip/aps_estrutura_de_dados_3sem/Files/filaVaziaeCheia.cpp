
// Fun��o para fila vazia e cheia
int Fila_vazia(Fila* fi);
int Fila_cheia(Fila* fi);

int Fila_cheia(Fila* fi){
    if(fi == NULL)
        return -1;
    if (fi -> quantidade == maximo)
        return 1;
    else
        return 0;
}

int Fila_vazia(Fila* fi){
    if(fi == NULL)
        return -1;
    if (fi -> quantidade == 0)
        return 1;
    else
        return 0;
}

