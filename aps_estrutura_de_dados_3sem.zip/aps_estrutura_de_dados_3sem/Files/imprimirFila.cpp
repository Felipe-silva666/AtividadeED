
// Fun��o para mostrar toda a fila, os prints podem ser alterados a medida da necessidade do programa
void imprime_Fila(Fila* fi);

void imprime_Fila(Fila* fi){
    if(fi == NULL)
        return;
    int n, i = fi -> inicio;
    for(n = 0; n < fi -> quantidade; n++){
        printf("Matricula: %d\n", fi -> dado[i].matricula);
        printf("Nome: %s\n", fi -> dado[i].nome);
        printf("Avalia��es: %.2f %.2f %.2f\n", fi -> dado[i].avaliacao1, fi -> dado[i].avaliacao2, fi -> dado[i].avaliacao3);
        i = (i + 1) %maximo;
    }
}

