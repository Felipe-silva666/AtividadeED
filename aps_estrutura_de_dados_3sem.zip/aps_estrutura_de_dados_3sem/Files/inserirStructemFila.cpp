// Fun��o para inserir uma struct na fila
int insere_Fila(Fila* fi, struct aluno);

int insere_Fila(Fila* fi, struct aluno){
    if(fi == NULL)
        return 0;
    if(Fila_cheia(fi))
        return 0;
    fi -> dado[fi -> final] = aluno;
    fi -> final = (fi-> final + 1) %maximo;
    fi -> quantidade++;
    return 1;
}

