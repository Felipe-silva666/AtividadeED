// Fun��o para liberar a fila, utilizando "free"
void libera_Fila(Fila* fi){
    free(fi);
}

