// Fun��o remover da fila
int remove_Fila(Fila* fi);


int remove_Fila(Fila* fi){
    if(fi == NULL || Fila_vazia(fi))
        return 0;
    fi -> inicio = (fi -> inicio + 1) %maximo;
    fi -> quantidade--;
    return 1;
}
