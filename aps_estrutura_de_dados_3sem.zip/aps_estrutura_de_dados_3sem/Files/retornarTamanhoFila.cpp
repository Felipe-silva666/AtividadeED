// Fun��o para retornar o tamanho da fila 
int tamanho_Fila(Fila* fi);

int tamanho_Fila(Fila* fi){
    if(fi == NULL)
        return - 1;
    return fi -> quantidade;
}

