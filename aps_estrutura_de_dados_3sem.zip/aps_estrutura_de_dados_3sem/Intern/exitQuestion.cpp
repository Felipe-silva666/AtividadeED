int main();

int ExitQuestion(){
	int closeProgram = false;
	char pressedKey;
	bool exit, y_n = false;
	
	system("cls");
	printf("Certeza quer sair do programa?\n\n");
	
	printf("- Sim \n");
	printf("-\033[44m \033[97mN�o \033[0m\n");
	
	printf("\n\n- Use as setas do teclado para selecionar.\n- Bot�o 'Enter' para responder.");
	
	
	while(closeProgram == false){
		pressedKey = _getch();
		
		if(pressedKey == 0x48){ //Up arrow
			y_n = true;
		} else if (pressedKey == 0x50){ //Down arrow
			y_n = false;
		}
		
		if(y_n == false){
			exit = false;
			
			system("cls");
			printf("Certeza quer sair do programa?\n\n");
			
			printf("- Sim \n");
			printf("-\033[44m \033[97mN�o \033[0m\n");
			
			printf("\n\n- Use as setas do teclado para selecionar.\n- Bot�o 'Enter' para responder.");	
		} else{
			exit = true;
			
			system("cls");
			printf("Certeza quer sair do programa?\n\n");
			
			printf("-\033[44m \033[97mSim \033[0m\n");
			printf("- N�o \n");
			
			printf("\n\n- Use as setas do teclado para selecionar.\n- Bot�o 'Enter' para responder.");
		}
		
		if(pressedKey == 0x0D){
			if(exit == false){
				system("cls");
				main();	
			} else{
				return EXIT_SUCCESS;
			}
		}
	}
}
